package com.dinks.dinks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DinksApplication {

	public static void main(String[] args) {
		SpringApplication.run(DinksApplication.class, args);
	}

}
