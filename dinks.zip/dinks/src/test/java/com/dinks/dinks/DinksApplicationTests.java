package com.dinks.dinks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DinksApplicationTests {

	@Test
	void contextLoads() {
	}

}
