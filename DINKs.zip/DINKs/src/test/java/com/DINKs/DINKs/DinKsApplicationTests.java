package com.DINKs.DINKs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DinKsApplicationTests {

	@Test
	void contextLoads() {
	}

}
